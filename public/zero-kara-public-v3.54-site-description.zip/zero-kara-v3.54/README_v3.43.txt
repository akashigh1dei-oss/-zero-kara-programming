v3.43 用語集の説明を詳しく（2026年10月12日）

1,000語すべてを「意味・詳しい説明・具体例・確認のポイント」の4段構成に変更。
短い定義と例を残し、関連概念との違い、使い方、注意点を追加。
説明の長いダイアログはスマホ画面内でスクロール可能に調整。
CSSの疑似クラス・疑似要素6語の分類の崩れを修正。
v3.42のAI相談室ラベル・動画・イラストを継承。

v3.42からの差し替え（3ファイル）：
public/index.html
public/assets/js/part-01.js
public/assets/css/site.css

v3.39からも上記3ファイルで対応。
用語の並び順・1,000語の番号・英語名の配列を維持。
公開サーバーへの自動反映は行っていません。

確認済み：
・1,000語の番号、既存の意味と具体例を維持
・全1,000語の説明画面への4項目の呼び出し
・キーワード、分類、英語順、あいうえお順の抽出処理
・JavaScript構文、内部参照、既存の公開前チェック
画面描画とスマホ実機での表示確認は未実施。

補足を確認した公式資料：
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types
https://developer.mozilla.org/en-US/docs/Web/API/Window/fetch
https://docs.python.org/3.12/library/functions.html
https://developers.cloudflare.com/kv/api/write-key-value-pairs/
