const storyQuizQuestions=[
{q:'複数の答えを順番にまとめて保存したい。適しているのは？',o:['配列','CSS','else'],a:0,h:'第20回の「箱をまとめる」考え方です。',w:'配列は複数のデータを順番にまとめて扱えます。'},
{q:'配列の一番最初の番号は？',o:['0','1','10'],a:0,h:'JavaScriptの配列は人間の数え方と少し違います。',w:'JavaScriptの配列は0番から始まります。'},
{q:'answers[0] が表すものは？',o:['配列の最初の要素','配列の最後の要素','配列の個数'],a:0,h:'角括弧の数字は位置を示します。',w:'[0]は配列の最初の要素を指定します。'},
{q:'同じ処理を10回繰り返したい。適しているのは？',o:['for文','metaタグ','CSS'],a:0,h:'第21回でコンピュータに繰り返しを任せました。',w:'for文は同じ処理を条件に従って繰り返します。'},
{q:'answers.length が表すものは？',o:['配列の要素数','文字の色','最初の答え'],a:0,h:'lengthは「長さ・個数」の手掛かりです。',w:'lengthで配列に入っている要素数を取得できます。'},
{q:'配列が10件から50件に増えても最後まで処理しやすい書き方は？',o:['lengthを使ったfor文','変数を50個手書き','CSSを50個作る'],a:0,h:'データ数が変わっても追従できる方法を考えます。',w:'配列のlengthを条件に使えば、要素数の変化に合わせて繰り返せます。'},
{q:'DOM操作でJavaScriptができることは？',o:['HTMLの画面内容を取得・変更する','パソコンの電源を作る','CSSファイルを紙に印刷するだけ'],a:0,h:'第22回では「画面を動かす」段階に進みました。',w:'DOMを通してJavaScriptからHTML要素を取得したり内容を変更したりできます。'},
{q:'document.getElementById("message") は何をする？',o:['idがmessageの要素を探す','messageというサイトを検索する','配列を削除する'],a:0,h:'getElementByIdを日本語に分けて考えます。',w:'指定したidを持つHTML要素を取得します。'},
{q:'HTML・CSS・JavaScriptの役割の組み合わせとして適切なのは？',o:['HTML=骨組み、CSS=見た目、JavaScript=動き','HTML=動き、CSS=計算、JavaScript=画像だけ','3つとも同じ役割'],a:0,h:'家にたとえた基本の役割を思い出します。',w:'HTMLが構造、CSSが見た目、JavaScriptが動作や処理を主に担当します。'},
{q:'第20〜22回の流れとして最も近いものは？',o:['データをまとめる→繰り返す→画面につなぐ','色を決める→印刷する→終了する','HTMLを消す→CSSを消す→JavaScriptを消す'],a:0,h:'配列→for文→DOMの順番です。',w:'配列で整理し、for文で繰り返し、DOMでHTML画面へつなぐ流れです。'}
];
let storyQuizIndex=0,storyQuizAnswers=[];
function renderStoryQuiz(){const q=storyQuizQuestions[storyQuizIndex];document.getElementById('storyQuizCounter').textContent='第'+(storyQuizIndex+1)+'問 / 全10問';document.getElementById('storyQuizBar').style.width=(storyQuizIndex/10*100)+'%';document.getElementById('storyQuizQuestion').textContent=q.q;document.getElementById('storyQuizHint').textContent='ヒント：'+q.h;document.getElementById('storyQuizFeedback').textContent='';const box=document.getElementById('storyQuizOptions');box.innerHTML='';q.o.forEach((x,i)=>{const b=document.createElement('button');b.className='btn secondary';b.style.margin='6px';b.textContent=x;b.onclick=()=>answerStoryQuiz(i,b);box.appendChild(b)});document.getElementById('storyQuizNext').hidden=true;document.getElementById('storyQuizPrev').hidden=storyQuizIndex===0;if(storyQuizAnswers[storyQuizIndex]!==undefined){document.querySelectorAll('#storyQuizOptions button').forEach(x=>x.disabled=true);const correct=storyQuizAnswers[storyQuizIndex]===q.a;document.getElementById('storyQuizFeedback').textContent=(correct?'正解！ ':'もう一歩。 ')+q.w;document.getElementById('storyQuizNext').hidden=false;}}
function answerStoryQuiz(i,b){if(storyQuizAnswers[storyQuizIndex]!==undefined)return;const q=storyQuizQuestions[storyQuizIndex];storyQuizAnswers[storyQuizIndex]=i;document.querySelectorAll('#storyQuizOptions button').forEach(x=>x.disabled=true);document.getElementById('storyQuizFeedback').textContent=(i===q.a?'正解！ ':'もう一歩。 ')+q.w;document.getElementById('storyQuizNext').hidden=false;}
function finishStoryQuiz(){const score=storyQuizQuestions.filter((q,i)=>q.a===storyQuizAnswers[i]).length;document.getElementById('storyQuizCounter').textContent='10問回答完了';document.getElementById('storyQuizBar').style.width='100%';document.getElementById('storyQuizQuestion').textContent='結果：10問中 '+score+'問正解';document.getElementById('storyQuizHint').textContent=score===10?'全問正解です。第20〜22回の要点をしっかりつかめています。':'間違えた問題を下で確認して、もう一度挑戦できます。';document.getElementById('storyQuizOptions').innerHTML='';document.getElementById('storyQuizFeedback').textContent='';document.getElementById('storyQuizNext').hidden=true;document.getElementById('storyQuizRetry').hidden=false;document.getElementById('storyQuizPrev').hidden=false;const r=document.getElementById('storyQuizReview');r.innerHTML='';storyQuizQuestions.forEach((q,i)=>{if(q.a===storyQuizAnswers[i])return;const p=document.createElement('p');p.className='note';p.textContent='第'+(i+1)+'問：正解は「'+q.o[q.a]+'」。'+q.w;r.appendChild(p)});}
document.addEventListener('DOMContentLoaded',()=>{renderStoryQuiz();document.getElementById('storyQuizPrev').addEventListener('click',()=>{if(storyQuizIndex>0){storyQuizIndex--;renderStoryQuiz();}});document.getElementById('storyQuizNext').addEventListener('click',()=>{if(storyQuizIndex===9)finishStoryQuiz();else{storyQuizIndex++;renderStoryQuiz();}});document.getElementById('storyQuizRetry').addEventListener('click',()=>{storyQuizIndex=0;storyQuizAnswers=[];document.getElementById('storyQuizRetry').hidden=true;document.getElementById('storyQuizReview').innerHTML='';renderStoryQuiz();});});






/* v2.33 sorting: verified direct DOM reorder */
(function(){
 function n(el){var order=el.getAttribute('data-editorial-order');if(order)return +order;var m=(el.textContent||'').match(/第\s*(\d+)\s*回/);return m?+m[1]:999999;}
 function init(pageId,newId,ascId,defaultMode){
   var page=document.getElementById(pageId), a=document.getElementById(newId), b=document.getElementById(ascId);
   if(!page||!a||!b)return;
   var list=[].slice.call(page.querySelectorAll('.lesson-item')).filter(function(x){return x.closest('.page')===page;});
   if(!list.length)return;
   var parent=list[0].parentNode;
   list=list.filter(function(x){return x.parentNode===parent;});
   list.forEach(function(x,i){x.dataset.v233Index=i;});
   var marker=document.createComment('v233-sort-marker');
   parent.insertBefore(marker,list[0]);
   function run(mode){
     var arr=list.slice().sort(function(x,y){
       var d=n(x)-n(y);
       if(!d)d=(+x.dataset.v233Index)-(+y.dataset.v233Index);
       return mode==='asc'?d:-d;
     });
     var frag=document.createDocumentFragment();
     arr.forEach(function(x){frag.appendChild(x);});
     parent.insertBefore(frag,marker.nextSibling);
     a.classList.toggle('active',mode==='newest'); b.classList.toggle('active',mode==='asc');
     a.setAttribute('aria-pressed',mode==='newest'); b.setAttribute('aria-pressed',mode==='asc');
   }
   if(defaultMode)run(defaultMode);
   a.addEventListener('click',function(e){e.preventDefault();run('newest');},true);
   b.addEventListener('click',function(e){e.preventDefault();run('asc');},true);
 }
 function boot(){init('lessons','sortNewestBtn','sortAscBtn','asc');init('editorialIndex','editorialNewestBtn','editorialAscBtn','newest');}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();


/* v2.87: build one navigation from the learning list and actual page order. */
(function(){
 function lessonRows(){
   var page=document.getElementById('lessons');if(!page)return [];
   return [].slice.call(page.querySelectorAll('.lesson-item')).map(function(row){
     var m=(row.textContent||'').match(/第\s*(\d+)\s*回/), b=row.querySelector('a[onclick], button[onclick]');
     var x=b&&b.getAttribute('onclick')||'', idm=x.match(/showPage\(['\"]([^'\"]+)/), om=x.match(/openLesson\((\d+)\)/);
     return m?{n:+m[1],id:idm?idm[1]:(om?'lesson'+om[1]:null)}:null;
   }).filter(function(x){return x&&x.id;}).sort(function(a,b){return a.n-b.n;});
 }
 function rootFor(id){
   var j=id.match(/^(jsLecture\d+)p\d+$/);if(j)return j[1]+'p1';
   var m=id.match(/^((?:python|sql|api)Lecture\d+)(?:_p\d+)?$/);return m?m[1]:id;
 }
 function pageNumber(id){var m=id.match(/(?:_p|p)(\d+)$/);return m?+m[1]:1;}
 function button(label,id,cls){
   var b=document.createElement('button');b.type='button';b.className='learning-nav-button '+cls;b.textContent=label;
   if(id)b.addEventListener('click',function(){showPage(id);});else b.disabled=true;
   return b;
 }
 function install(){
   var rows=lessonRows();if(!rows.length)return;
   var sections=[].slice.call(document.querySelectorAll('section.page[id]'));
   var groups=rows.map(function(row){
     var root=rootFor(row.id),pages=sections.filter(function(sec){return rootFor(sec.id)===root;});
     pages.sort(function(a,b){return pageNumber(a.id)-pageNumber(b.id);});
     return {row:row,pages:pages};
   }).filter(function(group){return group.pages.length;});
   groups.forEach(function(group,gi){group.pages.forEach(function(sec,pi){
     var card=sec.querySelector('article.card, .card');if(!card)return;
     [].slice.call(sec.querySelectorAll('.lesson-pager, .course-nav, .v235-course-nav, .article-nav')).forEach(function(old){
       if(old.closest('section.page')!==sec)return;
       var quiz=old.querySelector('button[onclick*="jsStoryQuiz18to20"]');
       if(quiz){quiz.classList.add('lesson-quiz-link');old.parentNode.insertBefore(quiz,old);}
       old.remove();
     });
     var before=pi?group.pages[pi-1].id:(gi?groups[gi-1].pages.slice(-1)[0].id:null);
     var after=pi<group.pages.length-1?group.pages[pi+1].id:(gi<groups.length-1?groups[gi+1].pages[0].id:null);
     var nav=document.createElement('nav');nav.className='unified-learning-nav';nav.setAttribute('aria-label','学習の進め方');
     var heading=document.createElement('div');heading.className='learning-nav-heading';
     heading.textContent='第'+group.row.n+'回'+(group.pages.length>1?' ・ '+(pi+1)+' / '+group.pages.length+'ページ':'');nav.appendChild(heading);
     if(group.pages.length>1){
       var nums=document.createElement('div');nums.className='learning-nav-pages';nums.setAttribute('aria-label','この回のページ');
       group.pages.forEach(function(p,i){var b=button(''+(i+1),p.id,'learning-nav-number');if(i===pi){b.setAttribute('aria-current','page');b.disabled=true;}nums.appendChild(b);});nav.appendChild(nums);
     }
     var pair=document.createElement('div');pair.className='learning-nav-pair';
     pair.appendChild(button('← 戻る',before,'learning-nav-prev'));
     pair.appendChild(button('メイン','lessons','learning-nav-list'));
     pair.appendChild(button('次へ →',after,'learning-nav-next'));
     nav.appendChild(pair);
     card.appendChild(nav);
   });});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
})();


/* v2.39: theme picker. Easy to extend by adding a button + CSS class. */
(function(){
  var KEY='zeroKaraThemeV239';
  var allowed=['simple','rose','rose-ornate'];
  function applyTheme(name){
    if(allowed.indexOf(name)<0) name='simple';
    document.body.classList.remove('theme-rose','theme-rose-ornate');
    if(name==='rose') document.body.classList.add('theme-rose');
    if(name==='rose-ornate') document.body.classList.add('theme-rose-ornate');
    document.querySelectorAll('.theme-choice[data-theme]').forEach(function(btn){
      btn.setAttribute('aria-pressed',String(btn.dataset.theme===name));
    });
    try{localStorage.setItem(KEY,name);}catch(e){}
  }
  function bootTheme(){
    var saved='simple'; try{saved=localStorage.getItem(KEY)||'simple';}catch(e){}
    applyTheme(saved);
    document.querySelectorAll('.theme-choice[data-theme]').forEach(function(btn){
      btn.addEventListener('click',function(){applyTheme(btn.dataset.theme);});
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bootTheme);else bootTheme();
})();
