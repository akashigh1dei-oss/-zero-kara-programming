v3.44 AI相談履歴と管理室連携（2026年10月16日）

このZIPは導入準備版です。公開サイトや管理画面へのデプロイは行っていません。
初期設定ではHELP_HISTORY_ENABLED=falseで、履歴の記録は無効です。
導入手順はSETUP_HISTORY_2026-10-16.mdを参照してください。

追加した機能
・AI処理受付後の相談件数／成功／エラー／結果未記録の集計
・利用者が同意した質問とAI回答だけを保存
・日本時間の日別集計、日付・キーワード・状態で検索、50件単位の表示
・管理室で会話をテストに指定して集計から除外（解除可能）
・記録ごとの削除、30日経過後の非表示と毎時の削除
・管理者メールとCloudflare Access JWTの署名・期限・発行元・AUDを検証
・保存の障害が起きてもAIの回答を返す

本文保存を断っても相談できます。本文を断った場合も、会話の匿名IDと日時・成否は記録します。
会話IDは読み込みごとに変わるため、会話数は実人数ではありません。
上限拒否や入力エラー、保存障害で記録できなかった受付は集計に含みません。
保存前の過去の相談は復元できません。

本体の変更
worker.js / help-history.js / wrangler.jsonc / wrangler.history.example.jsonc
public/index.html / public/assets/js/help-chat.js / public/assets/css/site.css
migrations/0001_help_history.sql / tests/history.test.mjs
README_v3.44.txt / SETUP_HISTORY_2026-10-16.md

別Worker用
admin-companion/ は既存管理室v1.0の構成を引き継いだv1.1です。
本体サイトとは別の非公開管理室リポジトリへ配置します。
自動で公開本体の管理ルートを追加する機能ではありません。

検証内容はVALIDATION_v3.44.txtに記載。
