# AI相談履歴の導入（v3.44 / 管理室v1.1）

履歴保存と管理室の実装済みファイルです。公開への反映とCloudflareの設定はまだ行っていません。
ZIPをそのまま差し替えるだけでは保存は始まりません。設定してから公開してください。

## 1. 保存先を作る

CloudflareのD1で `zero-kara-help-history` を1つ作成し、Database IDを控えます。
この保存先だけを本体 `zero-kara-prog` と管理室 `zero-kara-admin` の両方に接続します。
既存のKVやDurable Objectの中身を消したり変更したりする必要はありません。

D1のコンソールで `migrations/0001_help_history.sql` 全文を実行し、`help_history` テーブルを作成します。
CLIを使う場合は、次の設定後、本体ディレクトリで実行できます。

```bash
npx wrangler d1 migrations apply zero-kara-help-history --remote --config wrangler.jsonc
```

## 2. 本体の設定を準備する

`wrangler.history.example.jsonc` の `REPLACE_WITH_YOUR_D1_DATABASE_ID` を実際のDatabase IDに置き換え、その内容を本体の `wrangler.jsonc` に適用します。
本体の現在のCloudflare設定に、このZIP以外で追加したバインディングや変数がある場合は、それも維持して統合してください。特に今日の公開Workerが既に変更されている場合、このZIPのworker.jsをそのまま上書きする前に差分を確認してください。

必要な追加設定は次の3点です。

- D1のバインディング `HELP_HISTORY_DB`
- 変数 `HELP_HISTORY_ENABLED` を文字列の `"true"` にする
- Cron `17 * * * *` を設定（毎時17分に30日経過分を削除）

既存の `HELP_QUOTA`、Rate Limiter、Workers AI、`HELP_AI_ENABLED` は維持します。
本体の既定設定は履歴無効のままです。D1設定例を適用し忘れると記録は始まりません。
D1のテーブルを先に作成してください。

## 3. 管理室を準備する

`admin-companion/` 内のファイルだけを、別の非公開 `zero-kara-admin` リポジトリのルートへ配置します。
構成は `src/index.js`、`src/access.js`、`src/api.js`、`src/page.js`、`package.json`、`wrangler.jsonc` です。
本体の `public/` に管理室のコードを置かないでください。

管理室の `wrangler.jsonc` で次を設定します。

| 設定名 | 値 |
| --- | --- |
| `HELP_HISTORY_DB` の `database_id` | 本体と同じD1 Database ID |
| `ACCESS_TEAM_DOMAIN` | Zero Trustのチームドメイン。例：`your-team.cloudflareaccess.com`（https://や末尾/なし） |
| `ACCESS_AUD` | 管理室を保護するAccessアプリケーションのApplication Audience（AUD） |
| `ADMIN_EMAIL` | 認証済みの管理者メール `admin@mmdei.com` |

Cloudflare Accessの「この管理者だけ許可する」Google認証ポリシーを維持してください。
アプリケーションのホスト名全体（`/`だけでなく`/api/*`と`/admin.js`を含む）を保護します。
既存の管理室URLでログインします。workers.devを利用中なので `workers_dev: true` を維持し、プレビューURLは無効にしています。
署名検証もWorkerで行うため、別URLへ直接アクセスしても認証のない履歴取得は拒否されます。
設定が不十分な場合は403になります。公開前にAccessのAUDとチームドメインを照合してください。

## 4. 公開して接続を確認する

1. 管理室を更新し、ログイン後に空の履歴が表示されることを確認します。
2. 本体を更新して再読み込みします。相談室に保存の案内が出ることを確認します。
3. 同意欄を選ばずに1回質問し、管理室には本文なしで1件記録されることを確認します。
4. 同意欄を選んで1回質問し、管理室に質問と回答が表示されることを確認します。
5. 自分の会話を「テストにする」に指定します。通常の集計から除外され、「テストも含める」で表示されます。
6. 検索・日別集計・削除を確認します。未ログインの別ブラウザーでは履歴を取得できないことも確認します。
7. 本体のCron設定を確認し、初回の実行結果を確認します。

この段階まで終わって初めて「公開中の記録が保存される状態」です。
CLIでの本体公開は従来どおり `npm run deploy`、管理室は管理室のディレクトリで `npm run deploy` です。
本体の既存GitHub Actionsも `wrangler.jsonc` を使うため、履歴用設定の統合を先に行ってください。

## 記録の扱い

- 件数はAI処理の受付時点で記録し、完了後に成功・エラーを更新します。途中で処理が止まったものは「処理中・結果未記録」に残る場合があります。
- 保存に障害があった分は記録が欠ける場合があります。相談自体を止めないことを優先しています。
- 質問と回答の保存は送信ごとの任意同意です。同意は既定でオフ。以前の会話全体は保存しません。
- 記録の保存期間は30日。30日経過分は検索できず、毎時の削除処理で削除します。Cron停止時は削除が遅れるため実行状況を確認してください。
- Cloudflare側の復元用バックアップなどはプロバイダーの保存方針が適用されます。DB復元後は期限切れ記録を削除してから運用を再開してください。
- 生のIP、メール、氏名、送信ヘッダーは独自の相談履歴に保存しません。利用者が本文に個人情報を書いてしまった場合は、同意した本文の一部として残る可能性があるため、管理室から削除してください。
- 「会話を消す」はブラウザーの表示だけを消します。記録を消すには管理室の削除を使います。
- 10回/日・サイト全体100回/日の既存上限は維持。これはリクエスト数の制限で、金額そのものの上限ではありません。D1・Workers AI等の請求はCloudflareで確認します。
- この管理画面でサイト全体の攻撃件数や請求額が分かる機能は未実装です。

## 無効に戻す場合

本体の `HELP_HISTORY_ENABLED` を `"false"` にすると、新しい履歴の記録と同意欄の表示を止められます。
既存の履歴と削除用Cronはそのまま維持できます。本文を残したくない場合は管理室から削除してください。
管理室の認証設定は無効にしないでください。

## ローカル検証

本体のディレクトリで、Node.js 24以降を使って実行します。

```bash
node --test tests/history.test.mjs
node scripts/site-guard.mjs
npm ci
npx wrangler deploy --dry-run
```

テストではローカルSQLiteと偽のAI応答を使い、本番データ・AI・請求には接続しません。
参照したCloudflare公式資料：

- https://developers.cloudflare.com/d1/worker-api/d1-database/
- https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
- https://developers.cloudflare.com/workers/configuration/cron-triggers/
