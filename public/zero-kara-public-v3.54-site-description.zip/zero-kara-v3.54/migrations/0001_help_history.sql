CREATE TABLE IF NOT EXISTS help_history (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','success','error')),
  consent INTEGER NOT NULL CHECK (consent IN (0,1)),
  consent_version TEXT NOT NULL,
  question TEXT,
  answer TEXT,
  duration_ms INTEGER,
  is_test INTEGER NOT NULL DEFAULT 0 CHECK (is_test IN (0,1)),
  CHECK (consent = 1 OR (question IS NULL AND answer IS NULL))
);
CREATE INDEX IF NOT EXISTS help_history_created ON help_history(created_at DESC);
CREATE INDEX IF NOT EXISTS help_history_expiry ON help_history(expires_at);
CREATE INDEX IF NOT EXISTS help_history_session ON help_history(session_id);
