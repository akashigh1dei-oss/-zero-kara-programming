v3.35 (2026-10-08)
- iPhone AI consultation: keyboard-safe full viewport dialog; footer hidden while dialog is open.
- Learning numbering: JavaScript lecture labels aligned with global learning sequence (3–7).
- Based on v3.34; AI model/Worker logic unchanged.
