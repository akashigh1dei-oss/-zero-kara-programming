function dayStart(value) {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value))throw new Error('日付を確認してください。');
  const time=Date.parse(value+'T00:00:00+09:00');
  if(!Number.isFinite(time)||new Date(time+9*3600000).toISOString().slice(0,10)!==value)throw new Error('日付を確認してください。');
  return time;
}
export function historyFilter(url) {
  const today=new Date(Date.now()+9*3600000).toISOString().slice(0,10);
  const from=dayStart(url.searchParams.get('from')||today);
  const to=dayStart(url.searchParams.get('to')||today)+86400000;
  if(to<=from||to-from>31*86400000)throw new Error('検索期間は31日以内にしてください。');
  const clauses=['expires_at > ?','created_at >= ?','created_at < ?'];
  const values=[Date.now(),from,to];
  if(url.searchParams.get('include_test')!=='1')clauses.push('is_test = 0');
  const q=(url.searchParams.get('q')||'').trim();
  if(q.length>100)throw new Error('検索語は100文字以内です。');
  if(q){clauses.push('(instr(COALESCE(question,\'\'), ?) > 0 OR instr(COALESCE(answer,\'\'), ?) > 0)');values.push(q,q);}
  const status=url.searchParams.get('status')||'';
  if(status){if(!['success','error','pending'].includes(status))throw new Error('状態を確認してください。');clauses.push('status = ?');values.push(status);}
  return {where:clauses.join(' AND '),values};
}
export async function handleApi(request, env, url, json) {
  if(!env.HELP_HISTORY_DB)return json({error:'相談履歴DBが未接続です。'},503);
  const db=env.HELP_HISTORY_DB;
  if(request.method==='GET'&&url.pathname==='/api/history') {
    let filter;
    try{filter=historyFilter(url);}catch(e){return json({error:e.message},400);}
    const offset=Number(url.searchParams.get('offset')||0);
    if(!Number.isSafeInteger(offset)||offset<0||offset>100000)return json({error:'ページを確認してください。'},400);
    const {where,values}=filter;
    const results=await db.batch([
      db.prepare(`SELECT COUNT(*) AS total, COALESCE(SUM(status='success'),0) AS success,
        COALESCE(SUM(status='error'),0) AS errors, COALESCE(SUM(status='pending'),0) AS pending,
        COUNT(DISTINCT session_id) AS sessions FROM help_history WHERE ${where}`).bind(...values),
      db.prepare(`SELECT * FROM help_history WHERE ${where} ORDER BY created_at DESC, id DESC LIMIT 50 OFFSET ?`).bind(...values,offset),
      db.prepare(`SELECT date(created_at/1000,'unixepoch','+9 hours') AS day, COUNT(*) AS total,
        COALESCE(SUM(status='success'),0) AS success, COALESCE(SUM(status='error'),0) AS errors
        FROM help_history WHERE ${where} GROUP BY day ORDER BY day DESC`).bind(...values)
    ]);
    return json({summary:results[0].results[0],rows:results[1].results,daily:results[2].results,offset,limit:50});
  }
  if(request.method==='POST'&&['/api/delete','/api/test-session'].includes(url.pathname)) {
    if(request.headers.get('origin')!==url.origin||request.headers.get('X-Admin-Action')!=='1')return json({error:'この管理画面から操作してください。'},403);
    if(!(request.headers.get('content-type')||'').toLowerCase().startsWith('application/json'))return json({error:'JSONで送信してください。'},415);
    let payload;
    try {
      const reader=request.body?.getReader(); if(!reader)throw Error();
      let size=0,chunks=[];
      while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>1024){await reader.cancel();throw Error();}chunks.push(value);}
      const bytes=new Uint8Array(size);let pos=0;for(const chunk of chunks){bytes.set(chunk,pos);pos+=chunk.length;}
      payload=JSON.parse(new TextDecoder().decode(bytes));
    } catch {return json({error:'入力形式を確認してください。'},400);}
    if(!payload||typeof payload!=='object')return json({error:'入力形式を確認してください。'},400);
    if(url.pathname==='/api/delete') {
      if(typeof payload.id!=='string'||! /^[a-f0-9-]{36}$/.test(payload.id))return json({error:'履歴IDを確認してください。'},400);
      await db.prepare('DELETE FROM help_history WHERE id = ?').bind(payload.id).run();
      return json({success:true});
    }
    if(typeof payload.sessionId!=='string'||!/^[a-f0-9]{64}$/.test(payload.sessionId)||typeof payload.isTest!=='boolean')return json({error:'会話IDを確認してください。'},400);
    await db.prepare('UPDATE help_history SET is_test = ? WHERE session_id = ?').bind(payload.isTest?1:0,payload.sessionId).run();
    return json({success:true});
  }
  return json({error:'Not Found'},404);
}
