import { verifyAdmin } from './access.js';
import { handleApi } from './api.js';
import { html, script } from './page.js';
const headers={
  'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
  'X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','X-Robots-Tag':'noindex, nofollow',
  'Content-Security-Policy':"default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
};
const json=(body,status=200)=>Response.json(body,{status,headers});
export default {
  async fetch(request,env) {
    if(!await verifyAdmin(request,env))return json({error:'管理者の認証を確認できません。Access設定・管理者メール・AUDを確認してください。'},403);
    const url=new URL(request.url);
    try {
      if(url.pathname.startsWith('/api/'))return await handleApi(request,env,url,json);
      if(request.method!=='GET')return json({error:'Method Not Allowed'},405);
      if(url.pathname==='/')return new Response(html,{headers:{...headers,'Content-Type':'text/html; charset=utf-8'}});
      if(url.pathname==='/admin.js')return new Response(script,{headers:{...headers,'Content-Type':'text/javascript; charset=utf-8'}});
      return json({error:'Not Found'},404);
    } catch {
      console.warn(JSON.stringify({event:'admin_history_request_failed'}));
      return json({error:'相談履歴を取得できません。DB接続とテーブルの作成を確認してください。'},503);
    }
  }
};
