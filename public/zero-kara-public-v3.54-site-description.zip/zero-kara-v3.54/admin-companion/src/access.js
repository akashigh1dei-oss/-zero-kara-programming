// Verify Access JWT at the Worker, including on workers.dev / preview URLs.
let keyCache = {issuer:'',until:0,keys:[]};
function decode(value) {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error('invalid encoding');
  return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')), c=>c.charCodeAt(0));
}
export async function verifyAdmin(request, env) {
  const team=env.ACCESS_TEAM_DOMAIN;
  if (!team || !/^[a-z0-9-]+\.cloudflareaccess\.com$/.test(team) || !env.ACCESS_AUD || !env.ADMIN_EMAIL) return false;
  const jwt=request.headers.get('Cf-Access-Jwt-Assertion');
  if (!jwt || jwt.length>16384) return false;
  try {
    const parts=jwt.split('.'); if(parts.length!==3) return false;
    const header=JSON.parse(new TextDecoder().decode(decode(parts[0])));
    const claims=JSON.parse(new TextDecoder().decode(decode(parts[1])));
    const now=Math.floor(Date.now()/1000),issuer='https://'+team;
    if(header.alg!=='RS256'||typeof header.kid!=='string')return false;
    if(claims.iss!==issuer||!Number.isFinite(claims.exp)||claims.exp<=now)return false;
    if(claims.nbf!==undefined&&(!Number.isFinite(claims.nbf)||claims.nbf>now))return false;
    if(!Number.isFinite(claims.iat)||claims.iat>now+60)return false;
    const audiences=Array.isArray(claims.aud)?claims.aud:[claims.aud];
    if(!audiences.includes(env.ACCESS_AUD)||typeof claims.email!=='string'||claims.email.toLowerCase()!==env.ADMIN_EMAIL.toLowerCase())return false;
    if(keyCache.issuer!==issuer||keyCache.until<Date.now()) {
      const response=await fetch(issuer+'/cdn-cgi/access/certs',{signal:AbortSignal.timeout(5000),redirect:'error'});
      if(!response.ok)return false;
      const data=await response.json();
      if(!Array.isArray(data.keys))return false;
      keyCache={issuer,until:Date.now()+300000,keys:data.keys};
    }
    const jwk=keyCache.keys.find(k=>k.kid===header.kid&&k.kty==='RSA');
    if(!jwk)return false;
    const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
    return await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode(parts[2]),new TextEncoder().encode(parts[0]+'.'+parts[1]));
  } catch {return false;}
}
