v3.38 (2026-10-11)
- Video path aligned to GitHub: public/assets/videos/web-town-launch.mp4
- Visible version updated to v3.38
- CSS cache query updated to 3.38
- All other original files retained.
